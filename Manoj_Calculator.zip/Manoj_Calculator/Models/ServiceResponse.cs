﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Manoj_Calculator.Models
{
    public class ServiceResponse
    {
        public bool IsSucess { get; set; }
    }
}

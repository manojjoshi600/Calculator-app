﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Manoj_Calculator.Models
{
    public class CalculatorModel
    {
        [Range(0, 1, ErrorMessage = "Value Must be between 0 to 1")]
        public decimal FirstValue
        {
            get;
            set;
        }
        [Range(0, 1, ErrorMessage = "Value Must be between 0 to 1")]
        public decimal SecondValue
        {
            get;
            set;
        }
        public decimal Result
        {
            get;
            set;
        }
    }
}

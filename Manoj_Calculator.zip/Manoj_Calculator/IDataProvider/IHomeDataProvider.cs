﻿using Manoj_Calculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Manoj_Calculator.IDataProvider
{
    public interface IHomeDataProvider
    {
        ServiceResponse Calculate(CalculatorModel model, string command);
    }
}

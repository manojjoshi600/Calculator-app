﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Manoj_Calculator.Models;
using Manoj_Calculator.DataProvider;
using Manoj_Calculator.IDataProvider;

namespace Manoj_Calculator.Controllers
{
    public class HomeController : Controller
    {
        private IHomeDataProvider _dataProvider;

        public HomeController(IHomeDataProvider dataProvider)
        {
            _dataProvider = dataProvider;
        }

        [HttpGet]
        public IActionResult Calculator()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Calculator(CalculatorModel model, string command)
        {
            if (ModelState.IsValid)
            {
                _dataProvider.Calculate(model, command);
                return View(model);
            }
            return View(model);
        }
    }
}

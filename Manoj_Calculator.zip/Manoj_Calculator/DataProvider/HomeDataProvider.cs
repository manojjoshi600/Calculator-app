﻿using Manoj_Calculator.IDataProvider;
using Manoj_Calculator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Manoj_Calculator.DataProvider
{
    public class HomeDataProvider : IHomeDataProvider
    {
        private decimal Multiply(decimal FirstValue, decimal SecondValue)
        {
            return FirstValue * SecondValue;
        }

        public ServiceResponse Calculate(CalculatorModel model, string command)
        {
            ServiceResponse response = new ServiceResponse();
            try
            {
                switch (command)
                {
                    case "Multiplication":  // Abstracted class Multiply
                        model.Result = Multiply(model.FirstValue, model.SecondValue);
                        break;

                    case "Conditional_Probability":
                        model.Result = model.FirstValue + model.SecondValue - (Multiply(model.FirstValue, model.SecondValue));
                        break;

                    default:
                        response.IsSucess = false;
                        break;
                }

                response.IsSucess = true;
            }
            catch (Exception ex)
            {
                response.IsSucess = false;
                Console.WriteLine(ex.Message);
            }
            return response;
        }
    }
}
